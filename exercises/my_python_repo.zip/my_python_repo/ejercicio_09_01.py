nombres =  # obtener la lista de nombres de alumnos
tareas =  # obtener la lista de número de tareas
calificaciones =  # obtener la lista de calificaciones

# cadena de mensaje a ser usada para cada estudiante
# NOTA: use .format() con esta cadena en el bucle for
mensaje = "Hola {},\n\nEste es un recordatorio de que tiene {} tareas por entregar, \
antes de que pueda graduarse. Su calificación actual es {} y puede incrementarse \
a {} si entrega todas sus tareas antes de la fecha límite.\n\n"

# escriba su código usando un bucle for que itere sobre las listas de nombres, tareas y calificaciones
