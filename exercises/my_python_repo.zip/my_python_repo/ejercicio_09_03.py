def crea_elenco(archivo):
    elenco = []
    # usar with para abrir el archivo
    # use el bucle for para procesar cada línea
    # agregar el nombre del actor a la lista elenco

    return elenco

# no modificar este bloque del código
# ajustar solo la ruta del archivo si es necesario
elenco = crea_elenco('data_files/flying_circus_cast.txt')
for actor in elenco:
    print(actor)
